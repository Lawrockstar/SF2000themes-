SF2000
Exclusive theme for multicore


- GBC folder (GBC+GB) GB games can be transferred to the GBC folder
- GB(PCE) folder contains the PCengine game shortcuts
- GBA folder (MULTICORE) place your GBA roms shortcuts and other multicore ones,
 and ends with flotools to update the list





- Pasta GBC( GBC+GB) Os jogos do GB voce transfere para a pasta GBC
- Pasta GB(PCE) coloque os atalhos dos jogos do Pcengine
- Pasta GBA(MULTICORE) coloque as seus atalhos de roms de GBA e demais do multicore,
 e finaliza com flotools para atualizar a lista

tema criado por Lawrockstar.