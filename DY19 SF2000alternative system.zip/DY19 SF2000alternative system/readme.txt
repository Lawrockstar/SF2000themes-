If the sf2000 shows a black screen, in the bios folder,
 delete the bisrv.asd file>>> and copy the bisrv.asd from the bisrv_DY19_to_SF2000 folder and paste it back into the bios folder



Caso o sf2000 apresentar tela preta, na pasta bios apague o arquivo bisrv.asd>>> e copie o bisrv.asd da pasta bisrv_DY19_to_SF2000 e cole novamente na pasta bios